"""Current-user Windows DPAPI only. Never fall back to plaintext."""
import ctypes
import os
from pathlib import Path
import tempfile
from cj_client import CJError


def transform(data, *, decrypt=False):
    if os.name != 'nt':
        raise CJError('Protecao de credenciais disponivel apenas no Windows.')
    if not isinstance(data, bytes) or not 0 < len(data) <= 65536:
        raise CJError('Credencial local invalida.')
    class Blob(ctypes.Structure):
        _fields_ = [('size', ctypes.c_uint32), ('pointer', ctypes.POINTER(ctypes.c_ubyte))]
    buffer = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    target = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    fn = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    fn.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p if decrypt else ctypes.c_wchar_p,
                   ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p,
                   ctypes.c_uint32, ctypes.POINTER(Blob)]
    fn.restype = ctypes.c_int
    kernel.LocalFree.argtypes = [ctypes.c_void_p]; kernel.LocalFree.restype = ctypes.c_void_p
    # UI forbidden, without LOCAL_MACHINE: only the same Windows user can decrypt.
    if not fn(ctypes.byref(source), None if decrypt else 'ONAX CJ', None, None, None,
              1, ctypes.byref(target)):
        raise CJError('Windows nao conseguiu proteger ou abrir a credencial CJ.')
    try:
        if not target.pointer or target.size > 65536:
            raise CJError('Credencial local invalida.')
        return ctypes.string_at(target.pointer, target.size)
    finally:
        kernel.LocalFree(target.pointer)


def save(path, key):
    protected = transform(key.encode('utf-8'))
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.cj-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as file:
            file.write(protected); file.flush(); os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def load(path):
    try:
        encrypted = Path(path).read_bytes()
        return transform(encrypted, decrypt=True).decode('utf-8')
    except (OSError, UnicodeError):
        raise CJError('Credencial CJ local indisponivel; abrir Consultar CJ para configurar.') from None
