"""Compare normalized research evidence offline. No crawler or store writes."""
from datetime import datetime, timezone
from decimal import Decimal, ROUND_FLOOR
from core import Blocked, Costs, decimal
from pricing_scenarios import price_for_revenue_margin


def cost_ceiling(sale_price, margin, fees_rate):
    """Maximum fixed costs after ads 5%, reserve 2% and verified fee rate."""
    price = decimal(sale_price, 'sale_price')
    target = decimal(margin, 'margin')
    fees = decimal(fees_rate, 'fees_rate')
    if price <= 0 or not Decimal('.30') <= target <= Decimal('.50'):
        raise Blocked('invalid sale price or margin')
    remaining = Decimal('.93') - target - fees
    if remaining <= 0:
        raise Blocked('no feasible cost ceiling')
    return (price * remaining).quantize(Decimal('.01'), rounding=ROUND_FLOOR)


def assess(offer, *, now):
    """Research triage only: even complete evidence never publishes or buys."""
    if now.tzinfo is None:
        raise Blocked('timezone required')
    reasons = []
    try:
        seen = datetime.fromisoformat(offer['observed_at'].replace('Z', '+00:00'))
        age = (now - seen).total_seconds()
        if seen.tzinfo is None or age < 0 or age > 86400:
            reasons.append('evidencia_antiga_ou_data_invalida')
    except (KeyError, ValueError, TypeError):
        reasons.append('data_nao_confirmada')
    moq = offer.get('minimum_order')
    reject = type(moq) is int and moq > 1
    if reject:
        reasons.append('exige_compra_em_lote')
    elif type(moq) is not int or moq != 1:
        reasons.append('pedido_unitario_nao_confirmado')
    for field in ('variant_verified', 'pack_verified', 'price_revalidated',
                  'direct_fulfillment_verified', 'route_verified',
                  'ready_stock_verified', 'demand_verified'):
        if offer.get(field) is not True:
            reasons.append(field)
    if offer.get('moq_conflict') is True:
        reasons.append('quantidade_minima_contraditoria')
    if offer.get('cost_currency') != offer.get('sale_currency') or not offer.get('cost_currency'):
        reasons.append('moedas_nao_conciliadas')
    floors = None
    try:
        if offer.get('costs_verified') is not True:
            raise Blocked('custos_nao_verificados')
        costs = Costs(**offer['costs'])
        floors = {str(m): str(price_for_revenue_margin(costs, m)) for m in ('0.30', '0.50')}
    except (Blocked, TypeError, KeyError):
        reasons.append('custos_completos_pendentes')
    if floors:
        try:
            cap = decimal(offer.get('competitive_sale_price'), 'competitive_sale_price')
            if offer.get('comparison_verified') is not True:
                raise Blocked('comparacao_nao_verificada')
            if decimal(floors['0.30'], 'floor') > cap:
                reject = True
                reasons.append('preco_competitivo_nao_comporta_margem_30')
        except Blocked:
            reasons.append('comparacao_de_mercado_pendente')
    return {'id': offer['id'], 'status': 'DESCARTAR_OFERTA' if reject else
            ('ANALISAR' if reasons else 'PRONTO_PARA_REVISAO'),
            'reasons': reasons, 'price_floors': floors,
            'publish_allowed': False, 'purchase_allowed': False}


if __name__ == '__main__':
    import json
    import os
    from pathlib import Path
    if os.name == 'nt' and os.environ.get('LOCALAPPDATA'):
        from mining_runtime import run
        raise SystemExit(run())
    root = Path(__file__).resolve().parent
    evidence = json.loads((root / 'pesquisa_multiplataforma.json').read_text(encoding='utf-8'))
    results = [assess(item, now=datetime.now(timezone.utc)) for item in evidence['offers']]
    print(json.dumps({'mode': 'OFFLINE_RESEARCH_ONLY', 'results': results}, ensure_ascii=False, indent=2))
