import unittest
import os
from datetime import datetime, timezone
from unittest.mock import patch
from pathlib import Path
from types import SimpleNamespace
import xml.etree.ElementTree as ET
from cj_client import CJError
from mining_cj import mine, products, stock_summary
from mining_runtime import dashboard
import mining_runtime
import windows_vault


class Fake:
    def __init__(self): self.calls=[]
    def search(self, keyword, size):
        self.calls.append(('search',keyword))
        return {'content':[{'productList':[{'id':'p1'}]}]}
    def product_by_id(self,pid):
        self.calls.append(('product',pid))
        return {'pid':pid,'productNameEn':'<script>unsafe</script>','variants':[
            {'vid':'v1','variantSku':'exact-black','variantSellPrice':'3.10'},
            {'vid':'v2','variantSku':'other','variantSellPrice':'0.01'}]}
    def stock(self,sku):
        self.calls.append(('stock',sku))
        return [{'countryCode':'CN','cjInventoryNum':0,'factoryInventoryNum':1000}]
    def freight(self,vid,**kwargs):
        self.calls.append(('freight',vid,kwargs))
        return [{'shipping_usd':'12.28','method':'example','preliminary':True}]


class MiningTests(unittest.TestCase):
    def test_exact_variant_dedup_and_lower_bound(self):
        client=Fake(); report=mine(client)
        self.assertEqual(report['products_discovered'],1)
        self.assertEqual(report['variants_analyzed'],1)
        candidate=report['candidates'][0]
        self.assertEqual(candidate['known_cost_usd'],'15.38')
        self.assertEqual(candidate['price_lower_bounds_usd'],{'0.30':'24.42','0.50':'35.77'})
        self.assertIn(('stock','exact-black'),client.calls)
        self.assertIn('estoque_pronto_CJ_na_origem',candidate['pending'])
        self.assertFalse(candidate['net_margin_verified'])
        self.assertIsNone(candidate['approved_price'])
        self.assertFalse(report['purchase_allowed'])
        self.assertEqual(report['platforms']['Amazon'],'PENDENTE')
    def test_provider_error_stops_without_retry(self):
        client=Fake(); client.search=lambda *a,**kw: (_ for _ in ()).throw(CJError('secret untrusted server text'))
        report=mine(client)
        self.assertTrue(report['status'].startswith('INTERROMPIDO'))
        self.assertNotIn('secret',str(report))
        self.assertEqual(report['candidates'],[])
    def test_unknown_and_nonfinite_price_not_used(self):
        for bad in ['1-4','NaN',None,True,1.1]:
            client=Fake(); original=client.product_by_id
            def product(pid):
                value=original(pid);value['variants'][0]['variantSellPrice']=bad;return value
            client.product_by_id=product
            self.assertEqual(mine(client)['candidates'],[])
    def test_pid_mismatch_blocks(self):
        client=Fake();client.product_by_id=lambda pid: {'pid':'other','variants':[]}
        self.assertTrue(mine(client)['status'].startswith('INTERROMPIDO'))
    def test_unknown_search_shape_not_guessed(self):
        with self.assertRaises(CJError): products({'list':[{'pid':'x'}]})
    def test_factory_and_ready_stock_are_separate(self):
        self.assertEqual(stock_summary([{'countryCode':'CN','cjInventoryNum':0,'factoryInventoryNum':10}], 'CN'),
                         {'cj_ready_units':0,'factory_units':10})
        self.assertEqual(stock_summary([{'countryCode':'US','cjInventoryNum':True}], 'US')['cj_ready_units'],None)
    def test_html_escapes_supplier_text(self):
        page=dashboard(mine(Fake()))
        self.assertNotIn('<script>',page)
        self.assertIn('&lt;script&gt;',page)
    def test_batch_limit(self):
        for invalid in [0,13,True]:
            with self.assertRaises(ValueError): mine(Fake(),max_products=invalid)
    def test_categories_share_analysis_budget(self):
        client=Fake()
        client.search=lambda query, size: {'content':[{'productList':[
            {'id':query+'-'+str(i)} for i in range(5)]}]}
        report=mine(client,max_products=6)
        self.assertEqual(len({x['pid'].rsplit('-',1)[0] for x in report['candidates']}),6)
    def test_windows_secret_has_no_plaintext_fallback(self):
        with patch.object(windows_vault.os,'name','posix'):
            with self.assertRaises(CJError): windows_vault.transform(b'test-secret')

    def test_schedule_runs_in_current_session_without_new_logon(self):
        captured = []
        def execute(args, **kwargs):
            if args[0] == 'whoami':
                return SimpleNamespace(returncode=0,stdout='"user","S-1-5-21-123"')
            captured.append(ET.fromstring(Path(args[args.index('/XML')+1]).read_text(encoding='utf-16')))
            return SimpleNamespace(returncode=0)
        with patch.object(mining_runtime.subprocess,'run',side_effect=execute):
            self.assertTrue(mining_runtime.schedule(Path('/path with spaces/ONAX')))
        ns={'t':'http://schemas.microsoft.com/windows/2004/02/mit/task'}
        trigger=captured[0].find('t:Triggers/t:TimeTrigger',ns)
        self.assertEqual(trigger.find('t:Repetition/t:Interval',ns).text,'PT6H')
        self.assertIsNotNone(trigger.find('t:StartBoundary',ns))

    @unittest.skipUnless(os.name == 'nt', 'DPAPI requires Windows')
    def test_native_dpapi_round_trip(self):
        # Runs on the HP as part of release health before activation.
        original = b'ONAX-test-only-no-real-credential'
        encrypted = windows_vault.transform(original)
        self.assertNotIn(original, encrypted)
        self.assertEqual(windows_vault.transform(encrypted, decrypt=True), original)


if __name__ == '__main__': unittest.main()
