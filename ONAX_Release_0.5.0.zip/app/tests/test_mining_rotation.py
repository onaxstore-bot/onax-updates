import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from cj_client import CJClient, CJError
from mining_cj import mine, search_plan
from mining_runtime import run_batch, next_round
from test_mining_cj import Fake

class RotationTests(unittest.TestCase):
    def test_country_filter_sent_and_invalid_country_no_network(self):
        client = CJClient('test-key')
        with patch.object(client, '_call', return_value={}) as call:
            client.search('organizer', page=2, size=5, country='US')
            self.assertEqual(call.call_args.kwargs['params']['countryCode'], 'US')
            self.assertEqual(call.call_args.kwargs['params']['page'], 2)
            for bad in ['us', 'XX', True]:
                with self.assertRaises(CJError): client.search('organizer', country=bad)
            self.assertEqual(call.call_count, 1)

    def test_terms_and_pages_rotate_with_bounded_queries(self):
        plans = [search_plan(i) for i in range(30)]
        self.assertEqual(len({p['keyword'] for group in plans for p in group}), 18)
        self.assertEqual({p['page'] for group in plans for p in group}, {1,2,3,4,5})
        self.assertTrue(all(len(group)==6 for group in plans))
        self.assertTrue(all(sum(p['country']=='US' for p in group)==3 for group in plans))
        for bad in [-1, True, 1000000]:
            with self.assertRaises(ValueError): search_plan(bad)

    def test_us_route_requires_ready_exact_sku_stock(self):
        client=Fake()
        client.stock=lambda sku: [{'countryCode':'US','cjInventoryNum':4,'factoryInventoryNum':9000}]
        candidate=mine(client)['candidates'][0]
        self.assertEqual(candidate['origin'], 'US')
        self.assertEqual([c[2]['origin'] for c in client.calls if c[0]=='freight'], ['US'])
        self.assertIn('preco_da_variante_no_armazem_US',candidate['pending'])
        self.assertFalse(candidate['warehouse_price_verified'])
        self.assertIsNone(candidate['approved_price'])

    def test_us_factory_stock_does_not_enable_us_route(self):
        for count in [0, None, True]:
            client=Fake()
            client.stock=lambda sku: [{'countryCode':'US','cjInventoryNum':count,'factoryInventoryNum':999}]
            self.assertEqual(mine(client)['candidates'][0]['origin'], 'CN')

    def test_success_advances_cursor_and_preserves_previous_report(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            client=Fake()
            client.search=lambda *a,**k: {'content':[{'productList':[{'id':'p1'}]}]}
            first=run_batch(root,client)
            second=run_batch(root,client)
            self.assertEqual(first['round_number'],0)
            self.assertEqual(second['round_number'],1)
            self.assertEqual(next_round(root),2)
            previous=json.loads((root/'data'/'mineracao_cj_anterior.json').read_text())
            self.assertEqual(previous['round_number'],0)
            self.assertNotIn('test-key',(root/'data'/'mineracao_cj.json').read_text())

    def test_provider_failure_keeps_cursor_without_retry(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);client=Fake()
            client.search=lambda *a,**k: (_ for _ in ()).throw(CJError('private-provider-message'))
            report=run_batch(root,client)
            self.assertEqual(next_round(root),0)
            self.assertNotIn('private-provider-message',json.dumps(report))

    def test_corrupt_cursor_does_not_silently_reset(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'data').mkdir()
            (root/'data'/'mineracao_cursor.json').write_text('{"next_round":true}')
            with self.assertRaises(ValueError): next_round(root)
