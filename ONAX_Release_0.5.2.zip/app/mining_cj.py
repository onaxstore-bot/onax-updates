"""Bounded CJ discovery; estimates never become approved profit or orders."""
from datetime import datetime, timezone
from decimal import Decimal, ROUND_CEILING
from cj_client import CJError
from core import decimal, Blocked

QUERIES = ('home organizer', 'pet accessory', 'travel organizer',
           'fitness accessory', 'desk accessory', 'phone holder')
QUERY_GROUPS = (QUERIES, ('travel pouch', 'pet grooming', 'kitchen storage',
                'car organizer', 'cable organizer', 'laundry bag'),
                ('packing cube', 'garden accessory', 'desk storage',
                 'shoe organizer', 'cleaning brush', 'bathroom organizer'))


def search_plan(round_number):
    if type(round_number) is not int or not 0 <= round_number < 1000000:
        raise ValueError('Rodada invalida.')
    terms = QUERY_GROUPS[round_number % len(QUERY_GROUPS)]
    # Half of each batch searches US warehouses; alternate the terms assigned
    # to that filter on later rounds. Pages cycle 1-5 instead of growing forever.
    return [{'keyword': term, 'page': 1 + (round_number // 3) % 5,
             'country': 'US' if (i + round_number // 3) % 2 == 0 else None}
            for i, term in enumerate(terms)]


def products(data):
    if not isinstance(data, dict) or not isinstance(data.get('content'), list):
        raise CJError('Formato da busca CJ nao reconhecido.')
    rows = []
    for group in data['content']:
        if not isinstance(group, dict) or not isinstance(group.get('productList'), list):
            raise CJError('Formato da busca CJ nao reconhecido.')
        for row in group['productList']:
            if not isinstance(row, dict) or not isinstance(row.get('id'), str):
                raise CJError('Identificacao de produto ausente.')
            rows.append(row)
    return rows


def stock_summary(rows, origin):
    if not isinstance(rows, list):
        return {'cj_ready_units': None, 'factory_units': None}
    matched = [r for r in rows if isinstance(r, dict) and r.get('countryCode') == origin]
    def total(field):
        values = [r.get(field) for r in matched]
        if not values or any(type(v) is not int or v < 0 for v in values):
            return None
        return sum(values)
    return {'cj_ready_units': total('cjInventoryNum'), 'factory_units': total('factoryInventoryNum')}


def mine(client, *, now=None, max_products=12, round_number=None):
    if type(max_products) is not int or not 1 <= max_products <= 12:
        raise ValueError('Limite de produtos invalido.')
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        raise ValueError('Data requer fuso horario.')
    report = {'format': 1, 'observed_at': now.isoformat(), 'source': 'CJ_API',
              'destination': 'US', 'agent_version': '0.5.2',
              'status': 'CONCLUIDO', 'failure': None, 'skipped_candidates': [], 'searches_completed': 0,
              'products_discovered': 0, 'variants_analyzed': 0, 'candidates': [],
              'publish_allowed': False, 'purchase_allowed': False,
              'platforms': {'CJ': 'CONSULTA_API', 'Amazon': 'PENDENTE', 'AliExpress': 'PENDENTE',
                            'Alibaba': 'PENDENTE', 'Shopee': 'PENDENTE'}}
    plan = ([{'keyword': q, 'page': 1, 'country': None} for q in QUERIES]
            if round_number is None else search_plan(round_number))
    report['search_plan'] = plan
    report['round_number'] = round_number
    seen = set()
    discovered = []
    groups = []
    stage = 'busca'
    try:
        for query in plan:
            params = {'size': 5}
            if round_number is not None:
                params.update(page=query['page'], country=query['country'])
            rows = products(client.search(query['keyword'], **params))
            groups.append(rows)
            report['searches_completed'] += 1
            for row in rows:
                if row['id'] not in seen:
                    seen.add(row['id']); discovered.append(row)
        report['products_discovered'] = len(discovered)
        # Interleave categories so a small budget does not always analyze only
        # the first query. Deduplicate again across category overlaps.
        balanced = []
        balanced_seen = set()
        for index in range(max((len(group) for group in groups), default=0)):
            for group in groups:
                if index < len(group) and group[index]['id'] not in balanced_seen:
                    balanced.append(group[index]); balanced_seen.add(group[index]['id'])
        for row in balanced[:max_products]:
            try:
                stage = 'produto'
                detail = client.product_by_id(row['id'])
                if not isinstance(detail, dict) or detail.get('pid') != row['id']:
                    raise CJError('Detalhe nao corresponde ao produto pesquisado.')
                variants = detail.get('variants')
                if not isinstance(variants, list):
                    continue
                # Analyze a single exact variant per product. No cheapest-range substitution.
                matching = [v for v in variants if isinstance(v, dict) and
                            isinstance(v.get('vid'), str) and isinstance(v.get('variantSku'), str)]
                if not matching:
                    continue
                variant = matching[0]
                try:
                    price = decimal(variant.get('variantSellPrice'), 'variant_price')
                    if price <= 0:
                        continue
                except Blocked:
                    continue
                sku = variant['variantSku']; vid = variant['vid']
                stage = 'estoque'
                stocks = client.stock(sku)
                summary = stock_summary(stocks, 'CN')
                stock_us = stock_summary(stocks, 'US')
                # Never quote a US-origin route solely because a search filter
                # returned the product; verify ready stock for this exact SKU.
                origin = 'US' if stock_us['cj_ready_units'] else 'CN'
                origin_stock = stock_us if origin == 'US' else summary
                stage = 'frete'
                quotes = client.freight(vid, destination='US', origin=origin, quantity=1)
                cheapest = quotes[0]
                known_cost = price + decimal(cheapest['shipping_usd'], 'shipping')
                lower = {m: str((known_cost / (Decimal('.93') - Decimal(m))).quantize(
                    Decimal('.01'), rounding=ROUND_CEILING)) for m in ('0.30', '0.50')}
                pending = ['taxas_e_tributos', 'cambio', 'devolucoes', 'custos_fixos',
                           'demanda', 'preco_concorrente_mesma_variante', 'conteudo_do_pacote',
                           'pedido_unitario_e_entrega_direta', 'frete_por_endereco', 'conformidade_produto']
                if origin == 'US':
                    pending.append('preco_da_variante_no_armazem_US')
                if not origin_stock['cj_ready_units']:
                    pending.append('estoque_pronto_CJ_na_origem')
                report['candidates'].append({'pid': row['id'], 'title': str(detail.get('productNameEn') or '')[:300],
                    'variant_id': vid, 'sku': sku, 'observed_at': now.isoformat(),
                    'product_usd': str(price), 'stock_CN': summary, 'stock_US': stock_us,
                    'origin': origin, 'warehouse_price_verified': False,
                    'shipping_quote': cheapest, 'known_cost_usd': str(known_cost),
                    'price_lower_bounds_usd': lower, 'approved_price': None,
                    'net_margin_verified': False, 'status': 'CUSTOS_E_DEMANDA_PENDENTES',
                    'pending': pending, 'publish_allowed': False, 'purchase_allowed': False})
                report['variants_analyzed'] += 1
            except CJError as exc:
                details = exc.safe_details(stage)
                if details['reason'] in ('PRODUTO_INDISPONIVEL', 'ROTA_INDISPONIVEL'):
                    # A retired product or an empty route is local to this item.
                    # Never retry it or reinterpret it as available/free freight.
                    report['skipped_candidates'].append({'product_id': row['id'], **details})
                    continue
                raise
    except CJError as exc:
        report['failure'] = exc.safe_details(stage)
        # Stop on first provider error, including quota/auth limits; keep partial results.
        report['status'] = 'INTERROMPIDO_CJ_VERIFICAR_ACESSO_LIMITE_OU_REDE'
    report['products_discovered'] = len(discovered)
    report['candidates'].sort(key=lambda c: (c['origin'] != 'US', Decimal(c['known_cost_usd'])))
    return report
