import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from cj_client import CJClient, CJError, provider_error
from mining_cj import mine
from mining_runtime import run_batch, dashboard
from commercial_research import enrich
from test_mining_cj import Fake


class FailureTests(unittest.TestCase):
    def two_products(self):
        client = Fake()
        client.search = lambda *a, **k: {'content': [{'productList': [{'id': 'p1'}, {'id': 'p2'}]}]}
        return client

    def test_removed_product_does_not_abort_other_candidates(self):
        client = self.two_products()
        original = client.product_by_id
        def detail(pid):
            if pid == 'p1':
                raise provider_error('product/query', {'code': 1602001, 'message': 'private-token'})
            return original(pid)
        client.product_by_id = detail
        report = mine(client)
        self.assertEqual(report['status'], 'CONCLUIDO')
        self.assertEqual([c['pid'] for c in report['candidates']], ['p2'])
        self.assertEqual(report['skipped_candidates'][0]['cj_code'], 1602001)
        self.assertNotIn('private-token', json.dumps(report))
        self.assertFalse(report['publish_allowed'])

    def test_rate_quota_access_and_parameters_stop_without_followups(self):
        for code, reason in [(1600200, 'LIMITE'), (1600201, 'LIMITE'),
                             (16900500, 'LIMITE'), (1600014, 'ACESSO'), (1600300, 'PARAMETROS')]:
            client = self.two_products()
            calls = []
            def detail(pid):
                calls.append(pid)
                raise provider_error('product/query', {'code': code, 'message': 'private-key'})
            client.product_by_id = detail
            report = mine(client)
            self.assertTrue(report['status'].startswith('INTERROMPIDO'))
            self.assertEqual(calls, ['p1'])
            self.assertEqual(report['failure']['reason'], reason)
            self.assertEqual(report['failure']['stage'], 'produto')
            self.assertNotIn('private-key', json.dumps(report))

    def test_empty_route_skips_only_that_item_and_is_never_free(self):
        client = self.two_products()
        original = client.freight
        calls = []
        def freight(vid, **kwargs):
            calls.append(vid)
            if len(calls) == 1:
                raise CJError('untrusted text', path='logistic/freightCalculate', reason='ROTA_INDISPONIVEL')
            return original(vid, **kwargs)
        client.freight = freight
        report = mine(client)
        self.assertEqual([c['pid'] for c in report['candidates']], ['p2'])
        self.assertEqual(report['skipped_candidates'][0]['reason'], 'ROTA_INDISPONIVEL')
        self.assertEqual(report['status'], 'CONCLUIDO')

    @patch('cj_client.time.sleep')
    def test_real_client_keeps_provider_code_and_empty_route_reason(self, sleep):
        def transport(method, path, params, body, headers):
            if path == 'authentication/getAccessToken':
                return {'code': 200, 'result': True, 'data': {'accessToken': 'private-token'}}
            return {'code': 1600200, 'result': False, 'message': 'private-token'}
        client = CJClient('private-key', transport)
        with self.assertRaises(CJError) as cm:
            client.stock('sku')
        self.assertEqual(cm.exception.safe_details()['cj_code'], 1600200)
        self.assertEqual(cm.exception.safe_details()['stage'], 'estoque')
        client._transport = lambda *a: {'code': 200, 'result': True, 'data': []}
        with self.assertRaises(CJError) as cm:
            client.freight('vid')
        self.assertEqual(cm.exception.safe_details()['reason'], 'ROTA_INDISPONIVEL')

    def test_untrusted_metadata_and_http_limits_do_not_leak_or_skip(self):
        for code in [True, 'private-key', {'token': 'private-token'}, 10**20]:
            exc = CJError('private-key', path='private-url', code=code, reason='private-token')
            details = exc.safe_details('private-stage')
            self.assertEqual(details['stage'], 'consulta')
            self.assertIsNone(details['cj_code'])
            self.assertNotIn('private', json.dumps(details))
        self.assertEqual(provider_error('product/query', {'code': 1602001}, 429).safe_details()['reason'], 'LIMITE')

    def test_repeated_failures_preserve_latest_complete_report_and_cursor(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            good = run_batch(root, self.two_products())
            client = self.two_products()
            client.search = lambda *a, **k: (_ for _ in ()).throw(CJError('private-error', reason='REDE'))
            run_batch(root, client)
            run_batch(root, client)
            saved = json.loads((root/'data'/'mineracao_cj_ultima_concluida.json').read_text())
            self.assertEqual(saved, good)
            cursor = json.loads((root/'data'/'mineracao_cursor.json').read_text())
            self.assertEqual(cursor['next_round'], 1)
            current = json.loads((root/'data'/'mineracao_cj.json').read_text())
            self.assertEqual(current['failure']['reason'], 'REDE')
            self.assertNotIn('private-error', json.dumps(current))

    def test_postal_probe_failure_keeps_partial_routes_and_safe_diagnostic(self):
        client = self.two_products()
        client.stock = lambda sku: [{'countryCode': 'US', 'cjInventoryNum': 1, 'factoryInventoryNum': 0}]
        report = mine(client)
        calls = []
        original = client.freight
        def freight(vid, **kwargs):
            calls.append(kwargs['zip_code'])
            if len(calls) == 2:
                raise provider_error('logistic/freightCalculate', {'code': 1600201, 'message': 'private-key'})
            return original(vid, **kwargs)
        client.freight = freight
        enrich(report, client=client)
        self.assertEqual(calls, ['10001', '90001'])
        self.assertEqual(len(report['route_probes']['rows']), 1)
        self.assertEqual(report['route_probes']['failure']['reason'], 'LIMITE')
        self.assertNotIn('private-key', json.dumps(report))

    def test_upgrade_recovers_good_previous_report_before_overwrite(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = root/'data'
            data.mkdir()
            good = mine(self.two_products())
            (data/'mineracao_cj_anterior.json').write_text(json.dumps(good))
            (data/'mineracao_cj.json').write_text('{"status":"INTERROMPIDO"}')
            client = self.two_products()
            client.search = lambda *a, **k: (_ for _ in ()).throw(CJError('untrusted'))
            run_batch(root, client)
            self.assertEqual(json.loads((data/'mineracao_cj_ultima_concluida.json').read_text()), good)

    def test_dashboard_shows_failure_stage_and_code(self):
        client = self.two_products()
        client.stock = lambda sku: (_ for _ in ()).throw(provider_error('product/stock/queryBySku', {'code': 1600200}))
        page = dashboard(mine(client))
        self.assertIn('etapa estoque', page)
        self.assertIn('1600200', page)
        self.assertIn('LIMITE', page)


if __name__ == '__main__':
    unittest.main()
