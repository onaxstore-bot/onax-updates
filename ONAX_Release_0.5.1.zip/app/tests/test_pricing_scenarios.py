import unittest
from decimal import Decimal
from core import Costs, Blocked, profitability
from pricing_scenarios import price_for_revenue_margin, compare_bases, costs_with_store_fees


class MarginTests(unittest.TestCase):
    def store_costs(self, orders, **changes):
        args = dict(shopify_monthly='19', planned_monthly_orders=orders,
                    shopify_transaction_rate='.02', paypal_rate='.064',
                    paypal_fixed_fee='.60')
        args.update(changes)
        return costs_with_store_fees(self.costs(proportional_fees='0'), **args)

    def test_subscription_and_both_fees_are_in_net_margin(self):
        costs = self.store_costs('10')
        self.assertEqual(costs.overhead, '2.90')
        self.assertEqual(costs.fixed_fees, '1.60')
        self.assertEqual(Decimal(costs.proportional_fees), Decimal('.084'))
        for target in ('.30', '.50'):
            price = price_for_revenue_margin(costs, target)
            self.assertGreaterEqual(profitability(costs, price)['revenue_margin'], Decimal(target))
            self.assertLess(profitability(costs, price - Decimal('.01'))['revenue_margin'], Decimal(target))

    def test_lower_volume_needs_higher_price(self):
        self.assertGreater(price_for_revenue_margin(self.store_costs('1'), '.30'),
                           price_for_revenue_margin(self.store_costs('100'), '.30'))
        self.assertEqual(self.store_costs('3').overhead, '7.34')

    def test_unknown_fees_or_invalid_volume_block(self):
        for orders in ('0', '-1', '1.5', None, True):
            with self.assertRaises(Blocked):
                self.store_costs(orders)
        for field in ('shopify_monthly', 'shopify_transaction_rate', 'paypal_rate', 'paypal_fixed_fee'):
            with self.assertRaises(Blocked):
                self.store_costs('10', **{field: None})

    def costs(self, **changes):
        values = dict(product='10', freight='5', fixed_fees='1', tax_and_fx='2',
                      returns_reserve='1', overhead='1', proportional_fees='.03', ads_rate='.05')
        values.update(changes)
        return Costs(**values)

    def test_revenue_margin_after_ads_and_reserve(self):
        for target in ('.30', '.40', '.50'):
            costs = self.costs()
            price = price_for_revenue_margin(costs, target)
            self.assertGreaterEqual(profitability(costs, price)['revenue_margin'], Decimal(target))
            self.assertLess(profitability(costs, price - Decimal('.01'))['revenue_margin'], Decimal(target))

    def test_different_bases_are_not_interchangeable(self):
        rows = compare_bases(self.costs(), '.30')
        self.assertGreater(Decimal(rows[1]['price']), Decimal(rows[0]['price']))
        self.assertLess(Decimal(rows[0]['revenue_margin']), Decimal('.30'))
        self.assertTrue(all(x['can_publish'] is False for x in rows))

    def test_missing_cost_and_infeasible_margin_block(self):
        with self.assertRaises(Blocked):
            price_for_revenue_margin(self.costs(tax_and_fx=None), '.30')
        with self.assertRaises(Blocked):
            price_for_revenue_margin(self.costs(proportional_fees='.50'), '.50')

    def test_out_of_range_target_blocks(self):
        for value in ('.29', '.51', 'NaN', None):
            with self.assertRaises(Blocked):
                price_for_revenue_margin(self.costs(), value)
