import copy
import unittest
from decimal import Decimal
from cj_client import CJError
from commercial_research import enrich, scenario, US_ZIPS


def candidate(sku='a', ready=2):
    return {'sku': sku, 'variant_id': 'v-'+sku, 'origin': 'US',
            'stock_US': {'cj_ready_units': ready}, 'product_usd': '8',
            'shipping_quote': {'shipping_usd': '2'}, 'known_cost_usd': '10',
            'approved_price': None}


class CommercialTests(unittest.TestCase):
    def report(self, count=1):
        return {'status': 'CONCLUIDO', 'observed_at': '2026-10-10T12:00:00+00:00',
                'candidates': [candidate(str(i)) for i in range(count)]}

    def test_reference_rates_raise_floor_without_approving(self):
        report = enrich(self.report())
        c = report['candidates'][0]
        price = Decimal(c['fee_reference_lower_bounds_usd']['0.30'])
        self.assertGreaterEqual((price * Decimal('.846') - Decimal('10')) / price, Decimal('.30'))
        self.assertIsNone(c['approved_price'])
        self.assertFalse(c['net_margin_verified'])
        self.assertFalse(c['publish_allowed'])
        self.assertEqual(c['complete_cost_scenario']['status'], 'CUSTOS_COMPLETOS_PENDENTES')

    def test_no_more_than_nine_queries_exact_variant_and_ready_only(self):
        calls = []
        class Client:
            def freight(self, vid, **kwargs):
                calls.append((vid, kwargs))
                return [{'shipping_usd':'3', 'preliminary': True}]
        report=self.report(6)
        report['candidates'][0]['stock_US']['cj_ready_units'] = 0
        enrich(report, client=Client())
        self.assertEqual(len(calls), 9)
        self.assertNotIn('v-0', [v for v, _ in calls])
        self.assertEqual({k['zip_code'] for _, k in calls}, set(US_ZIPS))
        self.assertTrue(all(k['quantity']==1 and k['origin']=='US' for _, k in calls))
        self.assertTrue(all(not r['route_verified'] for r in report['route_probes']['rows']))

    def test_error_stops_immediately_and_keeps_partial_observation(self):
        calls=[]
        class Client:
            def freight(self, *args, **kwargs):
                calls.append(kwargs)
                if len(calls)==2: raise CJError('private provider text')
                return [{'shipping_usd':'3'}]
        r=enrich(self.report(3), client=Client())
        self.assertEqual(len(calls),2)
        self.assertEqual(len(r['route_probes']['rows']),1)
        self.assertEqual(r['route_probes']['status'], 'INTERROMPIDO_CJ_SEM_REPETICAO')
        self.assertNotIn('private provider text',str(r))

    def test_subscription_scenario_requires_currency_and_all_costs(self):
        config={'currency':'USD', 'shopify_monthly':'19', 'planned_monthly_orders':'10',
            'shopify_transaction_rate':'.02', 'paypal_rate':'.064', 'paypal_fixed_fee':'.30',
            'sku_costs':{'a':{'tax_and_fx':'1', 'returns_reserve':'1',
                              'other_overhead':'0', 'other_fee_rate':'0'}}}
        result=scenario(candidate(),config)
        price=Decimal(result['prices_usd']['0.30'])
        self.assertGreaterEqual((price*Decimal('.846')-Decimal('14.20'))/price,Decimal('.30'))
        self.assertFalse(result['publish_allowed'])
        missing=copy.deepcopy(config);missing['sku_costs']['a']['tax_and_fx']=None
        self.assertIsNone(scenario(candidate(),missing)['prices_usd'])
        config['currency']='BRL'
        self.assertIsNone(scenario(candidate(),config)['prices_usd'])

    def test_failed_discovery_does_not_probe_routes(self):
        class Client:
            def freight(self,*a,**k): raise AssertionError('unexpected network')
        report=self.report();report['status']='INTERROMPIDO_CJ_VERIFICAR_ACESSO_LIMITE_OU_REDE'
        self.assertEqual(enrich(report,client=Client())['route_probes']['status'],'NOT_EXECUTED')
