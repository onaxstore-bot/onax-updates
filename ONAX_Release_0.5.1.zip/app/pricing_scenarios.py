"""Explicit pricing bases. Arithmetic only; no product approval or store writes."""
from decimal import Decimal, ROUND_CEILING
from dataclasses import replace
from core import Blocked, Costs, decimal, profitability, price_for


def costs_with_store_fees(costs: Costs, *, shopify_monthly,
                          planned_monthly_orders, shopify_transaction_rate,
                          paypal_rate, paypal_fixed_fee):
    """Allocate subscription per order and include both providers' fees.

    All fixed amounts must use the same currency as costs.product. Rates are
    decimal fractions. Incoming costs must exclude these three store fees;
    other overhead and payment costs are retained. Volume is a scenario, not
    a sales forecast. Unknown costs block pricing; zero sales cannot fund a
    monthly subscription through product prices.
    """
    orders = decimal(planned_monthly_orders, 'planned_monthly_orders')
    if orders < 1 or orders != orders.to_integral_value():
        raise Blocked('planned_monthly_orders must be a positive integer')
    monthly = decimal(shopify_monthly, 'shopify_monthly')
    allocation = (monthly / orders).quantize(Decimal('.01'), rounding=ROUND_CEILING)
    rate = (decimal(costs.proportional_fees, 'proportional_fees')
            + decimal(shopify_transaction_rate, 'shopify_transaction_rate')
            + decimal(paypal_rate, 'paypal_rate'))
    updated = replace(
        costs,
        overhead=str(decimal(costs.overhead, 'overhead') + allocation),
        fixed_fees=str(decimal(costs.fixed_fees, 'fixed_fees')
                       + decimal(paypal_fixed_fee, 'paypal_fixed_fee')),
        proportional_fees=str(rate))
    updated.amounts()
    return updated


def price_for_revenue_margin(costs: Costs, target):
    target = decimal(target, 'target')
    if not Decimal('.30') <= target <= Decimal('.50'):
        raise Blocked('target must be 30% to 50% of sale revenue')
    fixed, rate = costs.amounts()
    denominator = 1 - rate - target
    if denominator <= 0:
        raise Blocked('no feasible price for this revenue margin')
    return (fixed / denominator).quantize(Decimal('.01'), rounding=ROUND_CEILING)


def compare_bases(costs: Costs, target):
    rows = []
    for basis, price in (('RETURN_ON_TOTAL_COST', price_for(costs, target)),
                         ('NET_MARGIN_ON_SALE', price_for_revenue_margin(costs, target))):
        metrics = profitability(costs, price)
        rows.append({'basis': basis, **{k: str(v) for k, v in metrics.items()},
                     'can_publish': False})
    return rows
