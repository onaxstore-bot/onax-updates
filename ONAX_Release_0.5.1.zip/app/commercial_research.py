"""Bounded read-only route probes and explicit, non-approved pricing scenarios."""
from decimal import Decimal, ROUND_CEILING
from core import Costs, Blocked, decimal
from cj_client import CJError
from pricing_scenarios import costs_with_store_fees, price_for_revenue_margin

US_ZIPS = ('10001', '90001', '60601')


def enrich(report, *, client=None, financial_config=None):
    # Public standard-rate reference only. No negotiated account fees inferred.
    report['pricing_reference'] = {
        'currency': 'USD', 'basis': 'NET_MARGIN_ON_SALE',
        'shopify_transaction_rate': '0.02', 'paypal_international_rate': '0.064',
        'ads_rate': '0.05', 'chatgpt_reserve': '0.02',
        'account_fees_verified': False,
        'source': 'https://www.paypal.com/br/business/paypal-business-fees',
        'excludes': ['paypal_fixed_fee', 'shopify_monthly_allocation',
                     'taxes', 'currency_conversion', 'returns', 'other_overhead']}
    for c in report['candidates']:
        cost = decimal(c['known_cost_usd'], 'known_cost_usd')
        c['fee_reference_lower_bounds_usd'] = {
            m: str((cost / (Decimal('.846') - Decimal(m))).quantize(
                Decimal('.01'), rounding=ROUND_CEILING)) for m in ('0.30', '0.50')}
        c['complete_cost_scenario'] = scenario(c, financial_config)
        c['approved_price'] = None
        c['net_margin_verified'] = False
        c['publish_allowed'] = c['purchase_allowed'] = False
    report['route_probes'] = {'status': 'NOT_EXECUTED', 'destination': 'US',
                              'quantity': 1, 'sample_zips': list(US_ZIPS), 'rows': []}
    if client is None or report['status'] != 'CONCLUIDO':
        return report
    probes = report['route_probes']
    # At most three ready-stock variants, ordered by known delivered cost.
    ready = [c for c in report['candidates']
             if type(c.get('stock_' + c['origin'], {}).get('cj_ready_units')) is int
             and c['stock_' + c['origin']]['cj_ready_units'] > 0]
    ready.sort(key=lambda c: Decimal(c['known_cost_usd']))
    probes['status'] = 'CONCLUIDO' if ready else 'SEM_ESTOQUE_PRONTO_PARA_AMOSTRA'
    try:
        for c in ready[:3]:
            for zip_code in US_ZIPS:
                quotes = client.freight(c['variant_id'], origin=c['origin'],
                                        destination='US', quantity=1, zip_code=zip_code)
                probes['rows'].append({'sku': c['sku'], 'variant_id': c['variant_id'],
                    'zip': zip_code, 'origin': c['origin'], 'quote': quotes[0],
                    'observed_at': report['observed_at'], 'route_verified': False})
    except CJError:
        probes['status'] = 'INTERROMPIDO_CJ_SEM_REPETICAO'
    return report


def scenario(candidate, config):
    result = {'status': 'CUSTOS_COMPLETOS_PENDENTES', 'prices_usd': None,
              'publish_allowed': False, 'purchase_allowed': False}
    if not isinstance(config, dict):
        return result
    try:
        # No silent BRL/USD conversion, guessed subscription, or guessed tax.
        if config.get('currency') != 'USD':
            raise Blocked('cost currency must be USD')
        extra = config['sku_costs'][candidate['sku']]
        costs = Costs(product=candidate['product_usd'],
            freight=candidate['shipping_quote']['shipping_usd'], fixed_fees='0',
            tax_and_fx=extra.get('tax_and_fx'), returns_reserve=extra.get('returns_reserve'),
            overhead=extra.get('other_overhead'), proportional_fees=extra.get('other_fee_rate'),
            ads_rate='0.05')
        costs = costs_with_store_fees(costs,
            shopify_monthly=config.get('shopify_monthly'),
            planned_monthly_orders=config.get('planned_monthly_orders'),
            shopify_transaction_rate=config.get('shopify_transaction_rate'),
            paypal_rate=config.get('paypal_rate'), paypal_fixed_fee=config.get('paypal_fixed_fee'))
        result.update(status='CENARIO_NAO_APROVADO',
            planned_monthly_orders=str(config['planned_monthly_orders']),
            prices_usd={m: str(price_for_revenue_margin(costs, m)) for m in ('0.30', '0.50')})
    except (Blocked, KeyError, TypeError):
        pass
    return result
