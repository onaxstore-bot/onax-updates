"""Read-only, bounded CJ shop audit. Data stays in the user's local report.

Reference: https://developers.cjdropshipping.com/en/api/api2/api/shop.html
"""
from cj_client import CJError


def invalid():
    raise CJError('Resposta de integracao invalida.', reason='RESPOSTA_INVALIDA')


def identifier(value):
    return isinstance(value, str) and 0 < len(value) <= 200 and value.strip() == value


def audit(client, observed_at, target='q7zarg-c9'):
    result = {'status': 'NAO_EXECUTADO', 'observed_at': observed_at,
              'shop': None, 'products': [], 'complete': False,
              'purchase_allowed': False, 'publish_allowed': False}
    try:
        shops = client._call('GET', 'shop/getShops')
        if not isinstance(shops, list) or any(not isinstance(s, dict) for s in shops): invalid()
        # Never choose the API default shop, fuzzy matches, or an unrelated shop.
        names = {target.casefold(), (target + '.myshopify.com').casefold()}
        matches = [s for s in shops if str(s.get('type', '')).casefold() == 'shopify'
                   and str(s.get('name', '')).casefold() in names]
        if len(matches) != 1:
            result['status'] = 'LOJA_NAO_IDENTIFICADA' if not matches else 'LOJA_AMBIGUA'
            return result
        shop = matches[0]
        if not identifier(shop.get('id')): invalid()
        result['shop'] = {k: shop.get(k) for k in
                          ('id', 'name', 'status', 'syncInventory', 'fulfillmentStatus')}
        if type(shop.get('status')) is not int or shop['status'] != 1:
            result['status'] = 'AUTORIZACAO_DA_LOJA_PENDENTE'
            return result
        page = client._call('GET', 'shop/product/queryPage', params={
            'shopId': shop['id'], 'pageNum': 1, 'pageSize': 10})
        if not isinstance(page, dict) or not isinstance(page.get('list'), list): invalid()
        rows = page['list']
        if len(rows) > 10 or type(page.get('total')) is not int or page['total'] < len(rows): invalid()
        result['total_products'] = page['total']
        for row in rows:
            if not isinstance(row, dict) or row.get('shopId') != shop['id'] or not identifier(row.get('platformProductId')):
                invalid()
            result['products'].append({k: row.get(k) for k in
                ('platformProductId', 'shopProductStatus', 'relevanceStatus')})
        links_page = client._call('GET', 'product/conn/connection', params={
            'shopId': shop['id'], 'page': 1, 'pageSize': 100})
        if not isinstance(links_page, dict) or not isinstance(links_page.get('list'), list): invalid()
        links = links_page['list']
        if len(links) > 100 or type(links_page.get('total')) is not int or links_page['total'] < len(links): invalid()
        result['connections'] = []
        for link in links:
            if not isinstance(link, dict) or link.get('shopId') != shop['id']: invalid()
            if not all(identifier(link.get(k)) for k in
                       ('platformProductId', 'platformVariantId', 'cjProductId', 'cjVariantId')): invalid()
            result['connections'].append({k: link.get(k) for k in
                ('platformProductId', 'platformVariantId', 'cjProductId', 'cjVariantId',
                 'cjSku', 'defaultArea', 'logistics', 'sourceCountryCode', 'targetCountryCode')})
        result['complete'] = page['total'] == len(rows) and links_page['total'] == len(links)
        result['status'] = 'CONSULTA_CONCLUIDA' if result['complete'] else 'CONSULTA_PARCIAL'
    except CJError as exc:
        result['status'] = 'CONSULTA_INTERROMPIDA'
        result['failure'] = exc.safe_details('consulta')
    return result
