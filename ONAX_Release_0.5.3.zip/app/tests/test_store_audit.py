import unittest
from cj_client import CJClient, CJError
from store_audit import audit


class Client:
    def __init__(self):
        self.calls=[]
        self.shops=[{'id':'s','name':'q7zarg-c9','type':'shopify','status':1,'email':'private'}]
        self.products={'total':1,'list':[{'shopId':'s','platformProductId':'p','relevanceStatus':2}]}
        self.links={'total':1,'list':[{'shopId':'s','platformProductId':'p',
            'platformVariantId':'v','cjProductId':'c','cjVariantId':'cv','secret':'private'}]}
    def _call(self,method,path,**kwargs):
        self.calls.append((method,path,kwargs))
        return {'shop/getShops':self.shops,'shop/product/queryPage':self.products,
                'product/conn/connection':self.links}[path]


class AuditTests(unittest.TestCase):
    def test_owned_shop_exact_mapping_and_no_private_fields(self):
        c=Client();r=audit(c,'now')
        self.assertTrue(r['complete'])
        self.assertEqual(r['connections'][0]['cjVariantId'],'cv')
        self.assertNotIn('private',str(r))
        self.assertFalse(r['publish_allowed'])
        self.assertEqual(len(c.calls),3)
        self.assertTrue(all(x[0]=='GET' for x in c.calls))
    def test_no_fallback_to_default_api_shop(self):
        c=Client();c.shops[0]['type']='api'
        self.assertEqual(audit(c,'now')['status'],'LOJA_NAO_IDENTIFICADA')
        self.assertEqual(len(c.calls),1)
    def test_duplicate_shop_stops(self):
        c=Client();c.shops*=2
        self.assertEqual(audit(c,'now')['status'],'LOJA_AMBIGUA')
    def test_revoked_authorization_stops(self):
        c=Client();c.shops[0]['status']=4
        self.assertEqual(audit(c,'now')['status'],'AUTORIZACAO_DA_LOJA_PENDENTE')
        self.assertEqual(len(c.calls),1)
    def test_other_shop_response_rejected(self):
        c=Client();c.links['list'][0]['shopId']='other'
        self.assertFalse(audit(c,'now')['complete'])
    def test_partial_page_never_complete(self):
        c=Client();c.products['total']=11
        r=audit(c,'now');self.assertEqual(r['status'],'CONSULTA_PARCIAL')
        self.assertFalse(r['complete'])
    def test_provider_failure_no_retry_no_secret(self):
        c=Client()
        def fail(*a,**k):
            c.calls.append(a);raise CJError('secret',code=1600200)
        c._call=fail;r=audit(c,'now')
        self.assertEqual(len(c.calls),1)
        self.assertEqual(r['failure']['reason'],'LIMITE')
        self.assertNotIn('secret',str(r))
    def test_connection_mutations_cannot_reach_transport(self):
        def transport(*a): raise AssertionError('must not call network')
        c=CJClient('test-only',transport=transport)
        for method in ('POST','DELETE','PATCH'):
            with self.assertRaises(CJError): c._call(method,'product/conn/connection')
    def test_malformed_totals_rejected(self):
        c=Client();c.products['total']=True
        self.assertFalse(audit(c,'now')['complete'])
