"""Per-user CJ research automation. No store writes, orders or payments."""
import csv
from datetime import datetime, timedelta
import html
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from xml.sax.saxutils import escape
from cj_client import CJClient, CJError
from mining_cj import mine
from commercial_research import enrich
from store_audit import audit as audit_store
import windows_vault


def local_root():
    if os.name != 'nt' or not os.environ.get('LOCALAPPDATA'):
        raise CJError('Automacao local requer o HP com Windows.')
    root = Path(os.environ['LOCALAPPDATA']) / 'ONAX'
    if not (root / 'updater.py').is_file() or not (root / 'active.json').is_file():
        raise CJError('Instalacao ONAX nao encontrada.')
    return root


def atomic(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.mining-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as file:
            file.write(content); file.flush(); os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary): os.unlink(temporary)


def schedule(root):
    result = subprocess.run(['whoami', '/user', '/fo', 'csv', '/nh'], capture_output=True,
                            text=True, timeout=10)
    row = next(csv.reader(io.StringIO(result.stdout)), [])
    sid = row[-1] if row else ''
    if result.returncode or not sid.startswith('S-1-'):
        raise CJError('Identificacao do Windows indisponivel.')
    python = Path(sys.executable); pythonw = python.with_name('pythonw.exe')
    executable = pythonw if pythonw.exists() else python
    # A time trigger also starts the cycle in the current session, even if the
    # HP stays on for days without another Windows logon.
    start = (datetime.now().astimezone() + timedelta(hours=6)).isoformat(timespec='seconds')
    xml = f'''<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
<Triggers><TimeTrigger><Repetition><Interval>PT6H</Interval><StopAtDurationEnd>false</StopAtDurationEnd></Repetition><StartBoundary>{escape(start)}</StartBoundary><Enabled>true</Enabled></TimeTrigger><LogonTrigger><Repetition><Interval>PT6H</Interval><StopAtDurationEnd>false</StopAtDurationEnd></Repetition><Enabled>true</Enabled><UserId>{escape(sid)}</UserId></LogonTrigger></Triggers>
<Principals><Principal id="Author"><UserId>{escape(sid)}</UserId><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
<Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries><StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><StartWhenAvailable>true</StartWhenAvailable><ExecutionTimeLimit>PT15M</ExecutionTimeLimit></Settings>
<Actions Context="Author"><Exec><Command>{escape(str(executable))}</Command><Arguments>{escape('"' + str(root / 'updater.py') + '" minerar')}</Arguments><WorkingDirectory>{escape(str(root))}</WorkingDirectory></Exec></Actions></Task>'''
    with tempfile.TemporaryDirectory() as temp:
        path = Path(temp) / 'mining.xml'; path.write_text(xml, encoding='utf-16')
        result = subprocess.run(['schtasks.exe', '/Create', '/TN', 'ONAX-Mineracao', '/XML', str(path), '/F'],
                                capture_output=True, timeout=20)
    return result.returncode == 0


def dashboard(report):
    failure = report.get('failure') or {}
    diagnostic = ''
    if failure:
        diagnostic = '<p>Diagnóstico: etapa ' + html.escape(str(failure.get('stage'))) + \
            ' · código CJ ' + html.escape(str(failure.get('cj_code'))) + \
            ' · HTTP ' + html.escape(str(failure.get('http_status'))) + \
            ' · motivo ' + html.escape(str(failure.get('reason'))) + \
            '. Sem repetição imediata.</p>'
    skipped = report.get('skipped_candidates', [])
    if skipped:
        diagnostic += '<p>Itens descartados por produto ou rota indisponível: ' + str(len(skipped)) + '</p>'
    integration = report.get('store_integration')
    if integration:
        diagnostic += '<p>Integração CJ/Shopify: ' + html.escape(str(integration['status'])) + \
            '. Consulta de autorização e vínculos existentes; não confirma processamento de pedidos ou pagamentos.</p>'
    rows = []
    for item in report['candidates']:
        esc = lambda v: html.escape(str(v), quote=True)
        lower = item['price_lower_bounds_usd']
        reference = item.get('fee_reference_lower_bounds_usd', {})
        rows.append('<tr>' + ''.join('<td>'+esc(v)+'</td>' for v in (
            item['title'], item['sku'], item.get('origin', 'CN') + ' → US',
            (item.get('stock_US', {}) if item.get('origin') == 'US' else item['stock_CN']).get('cj_ready_units'),
            item['known_cost_usd'], lower['0.30'], lower['0.50'],
            reference.get('0.30', 'pendente'), reference.get('0.50', 'pendente'),
            ', '.join(item['pending']))) + '</tr>')
    probes = report.get('route_probes', {})
    probe_rows = []
    for item in probes.get('rows', []):
        q = item['quote']
        probe_rows.append('<tr>' + ''.join('<td>'+html.escape(str(v), quote=True)+'</td>'
            for v in (item['sku'], item['origin'], item['zip'], q['method'],
                      q['shipping_usd'], q['transit_estimate'])) + '</tr>')
    return '''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>ONAX — pesquisa CJ</title><style>body{font:16px system-ui;margin:32px;color:#172335;background:#f6f8fb}table{border-collapse:collapse;background:white;width:100%}td,th{padding:12px;text-align:left;border:1px solid #d8e0e8}h1{color:#253767}small{display:block;margin:16px 0} .scroll{overflow:auto}</style>
<h1>ONAX — pesquisa CJ para os EUA</h1><p>Estado: ''' + html.escape(report['status']) + '''</p>''' + diagnostic + '''<p>Atualizado: ''' + html.escape(report['observed_at']) + '''</p>
<p>Produtos descobertos: ''' + str(report['products_discovered']) + ''' · Variantes analisadas: ''' + str(report['variants_analyzed']) + '''</p>
<p>Os valores incluem apenas produto e a cotação preliminar da origem indicada para os EUA. As colunas 30% e 50% são limites inferiores matemáticos após publicidade de 5% e reserva de 2%. Faltam taxas, tributos, câmbio, devoluções e custos fixos. Não são preços aprovados ou promessa de lucro.</p>
<p>As duas colunas com taxas de referência incluem também 2% Shopify e 6,40% PayPal internacional padrão publicado para contas brasileiras. A taxa real da conta, tarifa fixa, mensalidade e demais despesas continuam pendentes. Estes valores não são lucro líquido comprovado.</p>
<p>Amazon, AliExpress, Alibaba e Shopee: conexões pendentes. Nenhuma compra ou publicação executada.</p><div class="scroll"><table><tr><th>Produto</th><th>SKU exato</th><th>Rota</th><th>Estoque pronto CJ</th><th>Custo conhecido USD</th><th>Limite inferior 30% USD</th><th>Limite inferior 50% USD</th><th>30% com taxas de referência USD</th><th>50% com taxas de referência USD</th><th>Pendências</th></tr>''' + ''.join(rows) + '''</table></div>
<h2>Frete por CEP — amostra de pesquisa</h2><p>Estado: ''' + html.escape(str(probes.get('status', 'NOT_EXECUTED'))) + '''. Até três variantes com estoque pronto, quantidade uma. Cotações simples continuam preliminares; não comprovam cobertura nacional ou custo final.</p><div class="scroll"><table><tr><th>SKU</th><th>Origem</th><th>CEP EUA</th><th>Método</th><th>Frete USD</th><th>Trânsito informado</th></tr>''' + ''.join(probe_rows) + '''</table></div>
<small>Uma variante por produto, até 12 produtos por rodada. Estoque de fábrica não é estoque pronto CJ. As buscas alternam 18 termos e páginas de 1 a 5. Estoque pronto nos EUA tem prioridade, mas o preço do armazém ainda precisa ser confirmado. Sem dados de demanda, nenhum candidato é aprovado.</small></html>'''


def next_round(root):
    path = root/'data'/'mineracao_cursor.json'
    try:
        state = json.loads(path.read_text(encoding='utf-8'))
        number = state.get('next_round')
        if type(number) is not int or not 0 <= number < 1000000:
            raise ValueError('Cursor invalido.')
        return number
    except FileNotFoundError:
        return 0


def run_batch(root, client):
    number = next_round(root)
    report = mine(client, round_number=number)
    try:
        financial_config = json.loads((root/'data'/'custos_comerciais.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        financial_config = None
    enrich(report, client=client, financial_config=financial_config)
    # Stop all optional requests after a failed API phase. Reuse authentication.
    if report['status'] == 'CONCLUIDO' and report.get('route_probes', {}).get('status') != 'INTERROMPIDO_CJ_SEM_REPETICAO':
        report['store_integration'] = audit_store(client, report['observed_at'])
    write_report(root, report)
    # Partial failed batches keep their cursor; a later scheduled run retries
    # that same bounded plan, never a tight automatic retry loop.
    if report['status'] == 'CONCLUIDO':
        atomic(root/'data'/'mineracao_cursor.json', json.dumps({'next_round': (number + 1) % 1000000}))
    return report


def write_report(root, report):
    # Keep the previous observation separately; no report or key is uploaded.
    current = root/'data'/'mineracao_cj.json'
    last_complete = root/'data'/'mineracao_cj_ultima_concluida.json'
    # Upgrade recovery: an older installation may already have saved a failed
    # current report while its previous report is still the last good batch.
    old_previous = root/'data'/'mineracao_cj_anterior.json'
    if not last_complete.exists() and old_previous.is_file():
        historical = old_previous.read_text(encoding='utf-8')
        try:
            historical_report = json.loads(historical)
        except ValueError:
            historical_report = {}
        if isinstance(historical_report, dict) and historical_report.get('status') == 'CONCLUIDO':
            atomic(last_complete, historical)
    if current.is_file():
        previous = current.read_text(encoding='utf-8')
        atomic(root/'data'/'mineracao_cj_anterior.json', previous)
        try:
            previous_report = json.loads(previous)
        except ValueError:
            previous_report = {}
        if isinstance(previous_report, dict) and previous_report.get('status') == 'CONCLUIDO':
            atomic(last_complete, previous)
    atomic(root/'data'/'mineracao_cj.json', json.dumps(report, ensure_ascii=False, indent=2))
    atomic(root/'data'/'mineracao_cj.html', dashboard(report))
    if report['status'] == 'CONCLUIDO':
        atomic(last_complete, json.dumps(report, ensure_ascii=False, indent=2))


def run(root=None):
    root = root or local_root()
    try:
        key = windows_vault.load(root/'data'/'cj_key.dpapi')
        client = CJClient(key)
        report = run_batch(root, client)
        print(report['status'] + ': ' + str(report['variants_analyzed']) + ' variantes analisadas.')
        return 0 if report['status'] == 'CONCLUIDO' else 1
    except (CJError, OSError, ValueError):
        atomic(root/'data'/'mineracao_status.json', json.dumps({'status':'ACESSO_CJ_OU_EXECUCAO_PENDENTE'}))
        print('ACESSO_CJ_OU_EXECUCAO_PENDENTE. Nenhuma compra enviada.')
        return 1


def activate():
    from consultar_cj import read_key
    root = local_root()
    key = read_key(persistent=True)
    client = CJClient(key); client.authenticate()  # Do not save an unaccepted API key.
    windows_vault.save(root/'data'/'cj_key.dpapi', key)
    try:
        automatic = schedule(root)
    except (OSError, ValueError, subprocess.TimeoutExpired, CJError):
        automatic = False
    atomic(root/'data'/'mineracao_config.json', json.dumps({'automatic':automatic,'interval_hours':6,
                                                         'destination':'US','source':'CJ'}))
    print('CHAVE CJ PROTEGIDA PELO WINDOWS.')
    print('MINERACAO_PERIODICA_CONFIGURADA' if automatic else 'AGENDAMENTO_PENDENTE: execucao manual disponivel.')
    # Use the already authenticated client for the initial batch.
    report = run_batch(root, client)
    print(report['status'] + ': ' + str(report['variants_analyzed']) + ' variantes analisadas.')
    print('Relatorio local: ' + str(root/'data'/'mineracao_cj.html'))
    os.startfile(root/'data'/'mineracao_cj.html')
    return 0 if automatic and report['status'] == 'CONCLUIDO' else 1
